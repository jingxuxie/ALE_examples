"""Same as construct-edesigns.ipynb but for batch submission on Kahuna

This is designed to run in a job array over iterations.
"""

import pygsti
import numpy as np
import os
import itertools 
import time
import sys

sys.path.append('..')
import simtools

## PARAMETERS ##
sidelength = 15         # Number of qubits per side of square lattice

# Order of magnitude error rates for choosing the maximum depth of the circuits.
oneQgate_error = 0.001  # One-qubit gate error
spam_error = 0.005      # SPAM error
twoQgate_error = 0.01   # Two-qubit gate error

numcirc = 30            # Number of circuits per RBDesign
numproc = 30            # Number of processors to multiprocess over
                        # (28 is Kahuna compute partition, so this is oversubscribing slightly,
                        # but the context switching is better than 2 ranks doing double work)

seed = 20210610         # Seed for MirrorRBDesign seeding

if __name__ == '__main__':
    # Pull iteration number from environment
    job_array_id = int(os.environ.get('SLURM_ARRAY_TASK_ID', -1))
    assert (job_array_id >= 0), "Could not get job task id. Was this submitted as a SLURM job array?"

    pspec = simtools.create_processor_spec(sidelength)

    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    qsubsets = simtools.select_qubit_subsets(widths, sidelength)

    twoQgaterate = simtools.get_twoQgaterate(widths)

    depths = {}
    for w in widths:
        maxl = simtools.predicted_depth_limit(spam_error, oneQgate_error, twoQgate_error, w, twoQgaterate[w], target=0.01)
        depths[w] = [0] + [2**i for i in range(1, int(np.ceil(np.log2(maxl) + 1)))]
        print(w,  depths[w])

    num_all_circs = sum([numcirc*len(depths[w]) for w in widths])

    circs_done = 0
    time0 = time.time()
    for w in widths: 
        # Unique seed for every iteration and width
        wseed = seed + job_array_id*num_all_circs + circs_done

        time1 = time.time()    
        rbdesign = pygsti.protocols.MirrorRBDesign(pspec, depths[w], numcirc,
                                                   qubit_labels=qsubsets[w], 
                                                   sampler='edgegrab',
                                                   samplerargs=[twoQgaterate[w]],
                                                   seed=wseed,
                                                   num_processes=numproc)
        time2 = time.time()
        
        pygsti.io.write_empty_protocol_data(rbdesign, f'../data/mrb_edesign_{w}_{job_array_id}',
                                            clobber_ok=True)

        circs_done += len(depths[w]) * numcirc

        print(f'Total time for width {w}: {time2 - time1}')
    print(f'Total time for iteration {job_array_id}: {time2 - time0}')
