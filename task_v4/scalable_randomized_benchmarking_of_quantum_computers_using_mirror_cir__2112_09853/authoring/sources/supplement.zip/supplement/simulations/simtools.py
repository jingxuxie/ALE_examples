import pickle
import numpy as np
import multiprocessing as mp
import time

import pygsti
from pygsti.objects.composed_sv_pv import ComposedPOVM as _ComposedPOVM
from pygsti.objects import operation as _op
from pygsti.objects import povm as _povm
from pygsti.objects import spamvec as _spamvec
from pygsti.objects.label import Label as _Lbl

import composedcrosstalkmodel as ccm


def create_processor_spec(sidelength):

    numQs = sidelength ** 2
    print("Number of qubits is:", numQs)
    qubit_labels = ['Q'+str(i) for i in range(numQs)]

    edgegraph = []
    for flatind in range(numQs):
        (i, j) = np.unravel_index(flatind, (sidelength, sidelength))
        if i < sidelength - 1:
            connectedq = np.ravel_multi_index((i+1, j), (sidelength, sidelength))
            edgegraph.append(('Q'+str(flatind), 'Q'+str(connectedq)))
        if j < sidelength - 1:
            connectedq = np.ravel_multi_index((i, j+1), (sidelength, sidelength))
            edgegraph.append(('Q'+str(flatind), 'Q'+str(connectedq)))

    oneQgates = ['Gc{}'.format(i) for i in range(24)]
    pspec = pygsti.obj.ProcessorSpec(numQs, ['Gcnot']+oneQgates, qubit_labels=qubit_labels,
                                     availability={'Gcnot': edgegraph},
                                     construct_models=('clifford',), 
                                     construct_clifford_compilations={'absolute': ('paulis', '1Qcliffords')},
                                     verbosity=0)
    print("Process spec built!")
    
    return pspec


# Picks a qubit subset for each width. This picks them as near the side as possible, while being square-like.
def select_qubit_subsets(widths, sidelength, verbose=False):
    qsubsets = {}
    for w in widths:
        squarelength = int(np.ceil(np.sqrt(w)))
        if verbose:
            print(w,  squarelength**2)

        ravelled_qubit_indices = []
        for i in range(squarelength - 1):
            for j in range(squarelength - 1):
                ravelled_qubit_indices.append((i, j))

        it = 0
        while len(ravelled_qubit_indices) < w:
            if it % 2 == 0:
                ravelled_qubit_indices.append((it // 2, squarelength - 1))
            if it % 2 == 1:
                ravelled_qubit_indices.append((squarelength - 1, (it - 1) // 2))
            it += 1

        qlist = ['Q' + str(np.ravel_multi_index(qastup, (sidelength, sidelength))) for qastup in ravelled_qubit_indices]
        qlist.sort()
        qsubsets[w] = tuple(qlist)
        
    return qsubsets


# Used for selecting the maximum benchmark depth to use.
def predicted_depth_limit(spam, oneQgate, twoQgate, n, twoQgaterate, target=0.005):
    
    A = ((1-spam)*(1-oneQgate)**3)**n 
    if n > 1:
        p = (1-twoQgate)**(twoQgaterate) * (1-oneQgate)**(2*n - 2*(twoQgaterate))
    else:
        p = 1 - oneQgate  
    return np.log((target * (1 - 1/2**n)) / A) / np.log(p)


def get_twoQgaterate(widths):
    twoQgaterate = {}
    for w in widths:
        if w > 1:
            twoQgaterate[w] = w / 8
        else:
            twoQgaterate[w] = 0
    return twoQgaterate


## Model Construction ##

def create_crosstalk_free_model(pspec, sim, qubit_subset, oneQgate_error, twoQgate_error, readout_error):
    assert (len(qubit_subset) <= pspec.number_of_qubits), "Must have qubits in subset <= qubits in pspec"
    assert all([q in pspec.qubit_labels for q in qubit_subset]), "All qubits in subset must be in pspec"

    # Extract subset of pspec
    num_qubits = len(qubit_subset)
    subset_availability, subset_graph = _get_subset_graph(pspec, qubit_subset)

    # "Local" noisy gates
    local_gates = {}
    for gate in pspec.root_gate_names:
        std_op = _op.StaticStandardOp(gate, 'chp')
        if std_op.dim == 2:
            error = oneQgate_error
        elif std_op.dim == 4:
            error = twoQgate_error
        else:
            raise ValueError('Cannot assign error rate for op with dim %d', std_op.dim)
        
        err_op = _op.DepolarizeOp(std_op.dim, evotype='chp', initial_rate=error)
        local_gates[gate] = _op.ComposedOp([std_op, err_op])

    # No crosstalk
    crosstalk_gates = {}

    # Perfect prep
    prep_layers = {'rho0': _spamvec.ComputationalSPAMVec([0, ]*num_qubits, 'chp', 'prep')}

    # POVM with readout error
    povm_layers = _get_noisy_povm(num_qubits, readout_error)

    ctf_model = ccm.ComposedCrosstalkModel(num_qubits,
        local_gates,
        crosstalk_gates,
        prep_layers=prep_layers,
        povm_layers=povm_layers,
        qubit_labels=qubit_subset,
        availability=subset_availability,
        geometry=subset_graph,
        evotype='chp', simulator=sim,
        padded_idle='Gc0')

    return ctf_model

def create_full_crosstalk_model(pspec, sim, qubit_subset, oneQgate_error, twoQgate_error, readout_error,
                                twoQcrosstalk_rates=None):
    assert (len(qubit_subset) <= pspec.number_of_qubits), "Must have qubits in subset <= qubits in pspec"
    assert all([q in pspec.qubit_labels for q in qubit_subset]), "All qubits in subset must be in pspec"

    num_qubits = len(qubit_subset)
    subset_availability, subset_graph = _get_subset_graph(pspec, qubit_subset)

    # "Local" noisy gates
    local_gates = {}
    for gate in pspec.root_gate_names:
        std_op = _op.StaticStandardOp(gate, 'chp')
        if std_op.dim == 2:
            error = oneQgate_error
        elif std_op.dim == 4:
            error = twoQgate_error
        else:
            raise ValueError('Cannot assign error rate for op with dim %d', std_op.dim)
        
        err_op = _op.DepolarizeOp(std_op.dim, evotype='chp', initial_rate=error)
        local_gates[gate] = _op.ComposedOp([std_op, err_op])

    # This is a simplistic crosstalk model, where the error decays as you get further away from the target qubits
    if twoQcrosstalk_rates is None:
        longest_dist = int(np.max(subset_graph.shortest_path_distance_matrix()))
        twoQcrosstalk_rates = {i: 0.0035 * (1/1.001)**(i-1) for i in range(1, longest_dist)}

    # Build one noisy op for every distance
    local_noise_ops = {dist: _op.DepolarizeOp(2, evotype='chp', initial_rate=rate) for dist, rate in twoQcrosstalk_rates.items()}

    # Crosstalk noisy gates
    crosstalk_gates = {}
    for gate, avails in subset_availability.items():
        std_op = _op.StaticStandardOp(gate, 'chp')
        if std_op.dim == 2: # Skip any one-qubit gates
            continue

        for qubit_pair in avails:
            local_label = _Lbl(gate, qubit_pair) # Label for the corresponding local operation
            full_label = _Lbl(gate, qubit_subset) # Label of crosstalk operation

            crosstalk_op = _op.ComposedOp([], dim=2**num_qubits, evotype='chp')

            for target in qubit_subset:
                if target in qubit_pair:
                    # Skip target qubits, these have no crosstalk (and "local" error already handled above)
                    continue

                dist_from_gate = min([int(subset_graph.shortest_path_distance(target, q)) for q in qubit_pair])
                err_op = local_noise_ops[dist_from_gate]

                crosstalk_op.append(_op.EmbeddedOp(qubit_subset, [target], err_op))
            
            crosstalk_gates[local_label] = (full_label, crosstalk_op)

    # Perfect prep
    prep_layers = {'rho0': _spamvec.ComputationalSPAMVec([0,]*num_qubits, 'chp', 'prep')}

    # POVM with readout error
    povm_layers = _get_noisy_povm(num_qubits, readout_error)

    full_ct_model = ccm.ComposedCrosstalkModel(num_qubits,
        local_gates,
        crosstalk_gates,
        prep_layers=prep_layers,
        povm_layers=povm_layers,
        qubit_labels=qubit_subset,
        availability=subset_availability,
        geometry=subset_graph,
        evotype='chp', simulator=sim,
        padded_idle='Gc0')

    return full_ct_model

# Sampling strategy
# For each gate (using oneQ_ for 1-qubit and twoQ_ for 2-qubit as needed):
#   1. Sample a total strength of noise based on total_strength variable
#   2. Sample a fraction of the strength to occur on the target qubits based on the local_interval variable
#   3. Split the local noise over all Paulis on the target qubits (3 for one-qubit, 15 for two-qubit)
#   4. Split the neighbor noise over all weight-1 Paulis on the neighbor qubits (3*N for N neighbors)
#      Note: Skip step 4 for idle and Z rotations (these will have local noise only)
#   5. Sample readout noise based on the total_strength variable
# If random_rates is False, use total_strength and uniform distribution of noise
def create_uncorrelated_nearest_neighbor_crosstalk_model(pspec, sim, qubit_subset, rand_state=None, random_rates=True,
                                                         oneQ_total_strength=0.002, twoQ_total_strength=0.02,
                                                         oneQ_local_interval=[0.5, 1], twoQ_local_interval=[0.5, 1],
                                                         readout_total_strength=0.01):
    assert (len(qubit_subset) <= pspec.number_of_qubits), "Must have qubits in subset <= qubits in pspec"
    assert all([q in pspec.qubit_labels for q in qubit_subset]), "All qubits in subset must be in pspec"

    if rand_state is None:
        rand_state = np.random.RandomState()

    num_qubits = len(qubit_subset)
    subset_availability, subset_graph = _get_subset_graph(pspec, qubit_subset)

    # Gates corresponding to Z rotations have no crosstalk
    # since they are usually implemented in software
    # These are I, Z(pi), Z(pi/2), and Z(-pi/2) respectively
    ctf_gates = ['Gc0', 'Gc9', 'Gc14', 'Gc23']

    # "Local" noisy gates
    # Also save how much noise to split over the neighbors later
    local_gates = {}
    neighbor_noise = {}
    for gate in pspec.root_gate_names:
        std_op = _op.StaticStandardOp(gate, 'chp')

        if std_op.dim == 2:
            total_strength = oneQ_total_strength
            local_interval = oneQ_local_interval
            num_rates = 3
        elif std_op.dim == 4:
            total_strength = twoQ_total_strength
            local_interval = twoQ_local_interval
            num_rates = 15
        else:
            raise ValueError('Cannot assign error rate for op with dim %d', std_op.dim)
        
        # No random defaults:
        # Full strength, average on local, and uniform distribution
        strength_factor = 1
        local_factor = np.average(local_interval)
        weights = np.ones(num_rates)

        # Randomize if needed
        if random_rates:
            strength_factor = rand_state.rand()
            local_factor = rand_state.rand() * (local_interval[1] - local_interval[0]) + local_interval[0]
            rand_weights = rand_state.rand(num_rates)
            weights = rand_weights / np.linalg.norm(rand_weights, ord=1)

        # Build op
        total_strength *= strength_factor
        local_strength = total_strength * local_factor
        rates = weights * local_strength

        err_op = _op.StochasticNoiseOp(std_op.dim, evotype='chp', initial_rates=rates)
        local_gates[gate] = _op.ComposedOp([std_op, err_op])

        # Save neighbor strength for later
        neighbor_noise[gate] = total_strength  - local_strength

    def sample_neighbor_noise(neighbors, neighbor_noise):
        num_neighbors = len(neighbors)

        # Split amongst all Pauli channels in neighbors
        # No random default: Uniform distribution
        weights = np.ones(3*num_neighbors)

        if random_rates:
            rand_weights = rand_state.rand(3*num_neighbors)
            weights = rand_weights / np.linalg.norm(rand_weights, ord=1)

        noise_op = _op.ComposedOp([], evotype='chp', dim=2**len(qubit_subset))

        # Assign stochastic rates
        for i, neighbor in enumerate(neighbors):
            rates = neighbor_noise * weights[3*i:3*(i+1)]
            noise_op.append(
                _op.EmbeddedOp(qubit_subset, [qubit_subset[neighbor]],
                    _op.StochasticNoiseOp(2, evotype='chp', initial_rates=rates)
                )
            )

        return noise_op

    # Crosstalk gates
    crosstalk_gates = {}
    for gate in pspec.root_gate_names:
        if gate in ['Gc0', 'Gc9', 'Gc14', 'Gc23']:
            # Skip idle and Z rotations
            continue

        if local_gates[gate].dim == 2:
            # Single qubit gate, we need an op for every qubit
            for target in qubit_subset:
                # Get all neighbors by finding non-zeros in connectivity matrix
                neighbors = set(np.where(subset_graph._connectivity[qubit_subset.index(target), :] != 0)[0])

                noise_op = sample_neighbor_noise(neighbors, neighbor_noise[gate])

                # Save op
                local_label = _Lbl(gate, target) # Label for the corresponding local operation
                full_label = _Lbl(gate, qubit_subset) # Label of crosstalk operation

                crosstalk_gates[local_label] = (full_label, noise_op)
        elif local_gates[gate].dim == 4:
            avails = subset_availability.get(gate, None)
            if avails is None:
                continue

            for qubit_pair in avails:
                # Get all neighbors by finding non-zeros in connectivity matrix
                neighbors = set(np.where(subset_graph._connectivity[qubit_subset.index(qubit_pair[0]), :] != 0)[0])
                neighbors.update(np.where(subset_graph._connectivity[qubit_subset.index(qubit_pair[1]), :] != 0)[0])

                # Remove target qubits from neighbors...
                neighbors -= set([qubit_subset.index(q) for q in qubit_pair])

                noise_op = sample_neighbor_noise(neighbors, neighbor_noise[gate])

                # Save op
                local_label = _Lbl(gate, qubit_pair) # Label for the corresponding local operation
                full_label = _Lbl(gate, qubit_subset) # Label of crosstalk operation

                crosstalk_gates[local_label] = (full_label, noise_op)
        else:
            raise ValueError('Cannot assign error rate for op with dim %d', local_gates[gate].dim)

    # Perfect prep
    prep_layers = {'rho0': _spamvec.ComputationalSPAMVec([0,]*num_qubits, 'chp', 'prep')}

    # Noisy POVM
    readout_error = readout_total_strength
    if random_rates:
        readout_error *= rand_state.rand()

    povm_layers = _get_noisy_povm(num_qubits, readout_error)

    nn_ct_model = ccm.ComposedCrosstalkModel(num_qubits,
        local_gates,
        crosstalk_gates,
        prep_layers=prep_layers,
        povm_layers=povm_layers,
        qubit_labels=qubit_subset,
        availability=subset_availability,
        geometry=subset_graph,
        evotype='chp', simulator=sim,
        padded_idle='Gc0')

    return nn_ct_model


def compute_model_infidelity(mdlfile, datadir, iterations, iter_to_skip, num_processes):
    with open(mdlfile, 'rb') as f:
        mdl = pickle.load(f)

    width = len(mdl.qubit_labels)

    time0 = time.time()
        
    layer_infidelities = []
    with mp.Pool(num_processes) as pool:
        args = [(mdl, datadir, width, i) for i in iterations if i != iter_to_skip]
        infids = pool.map(_handle_iteration, args)
        
        for infid in infids:
            layer_infidelities.extend(infid)
        
    avg = np.mean(layer_infidelities)
    std = np.std(layer_infidelities)
    print(f'Average: {avg} Standard Dev: {std} Number of samples: {len(layer_infidelities)}')

    print(f'Completed sampling for {mdlfile} in {time.time() - time0}')

    return avg


def compute_layer_infidelity(model, clifford_layer, pauli_layer):
    # Will need to keep track of every error channel on every qubit (for the most general case)
    qubit_error_rates = {q: {'I': 1, 'X': 0, 'Y': 0, 'Z': 0} for q in model.qubit_labels}
    
    def compose_qubit_rates(r1, r2):
        return {
            'I': r1['I']*r2['I'] + r1['X']*r2['X'] + r1['Y']*r2['Y'] + r1['Z']*r2['Z'],
            'X': r1['I']*r2['X'] + r1['X']*r2['I'] + r1['Y']*r2['Z'] + r1['Z']*r2['Y'],
            'Y': r1['I']*r2['Y'] + r1['Y']*r2['I'] + r1['X']*r2['Z'] + r1['Z']*r2['X'],
            'Z': r1['I']*r2['Z'] + r1['Z']*r2['I'] + r1['X']*r2['Y'] + r1['Y']*r2['X']
        }
    
    # Workhorse function, recursively go through op and add any stochastic noise
    # to the qubit_error_rates
    def process_error_rates_from_op(op, target_qubits=None):
        if isinstance(op, _op.ComposedOp):  # Call on each component
            for factor in op.factorops:
                process_error_rates_from_op(factor, target_qubits)
        elif isinstance(op, _op.EmbeddedOp):  # Call on embedded op with subset targets
            process_error_rates_from_op(op.embedded_op, op.targetLabels)
        elif isinstance(op, _op.StochasticNoiseOp):  # Handle the StochasticNoiseOp
            num_qubits = len(target_qubits)
            assert(2**num_qubits == op.dim), \
                f"Have dim {op.dim} but expected {2**num_qubits} for qubits {target_qubits}"
            
            # Retrieve rates and labels
            stochastic_rates = op._params_to_rates(op.params)
            
            basis = pygsti.obj.BuiltinBasis('pp', 4**num_qubits)
            rate_labels = basis.labels[1:]  # Skip identity
            
            # Run through each target (this works for any number of qubits)
            for i, qubit in enumerate(target_qubits):
                qubit_rates = {'I': 1-sum(stochastic_rates), 'X': 0, 'Y': 0, 'Z': 0}
                
                # Get marginalized error rates
                for rate, label in zip(stochastic_rates, rate_labels):
                    qubit_rates[label[i]] += rate
                
                qubit_error_rates[qubit] = compose_qubit_rates(qubit_error_rates[qubit], qubit_rates)

        elif isinstance(op, _op.StaticStandardOp): # Don't do anything for perfect op
            pass
        else: # Error on unexpected type
            raise ValueError(f'Did not expect op of type {type(op)}')
    
    # Handle full Clifford layer
    c_op = model.circuit_layer_operator(clifford_layer)
    process_error_rates_from_op(c_op, model.qubit_labels)  # Add noise from Clifford ops
    
    # Handle Pauli layer
    p_op = model.circuit_layer_operator(pauli_layer)
    process_error_rates_from_op(p_op, model.qubit_labels)  # Add noise from Pauli ops
    
    # Finally turn into the layer infidelity
    layer_fidelity = np.prod([q['I'] for q in qubit_error_rates.values()])
    return 1 - layer_fidelity


def infidelity_to_polarization(eps, n):
    return 1 - ((4**n * eps) / (4**n - 1))


def polarization_to_infidelity(p, n):
    return (4**n - 1) * (1 - p) / 4**n


def compose_fidelities(f1, f2, n):
    p1 = infidelity_to_polarization(1 - f1, n)
    p2 = infidelity_to_polarization(1 - f2, n)
    return 1 - polarization_to_infidelity(p1 * p2, n)


## Helper functions ##

def _get_subset_graph(pspec, qubit_subset):
    # Extract subset of pspec
    subset_availability = {}
    for gate, availlist in pspec.availability.items():
        subset_availlist = []
        
        # Check all qubits in one availability are in our subset
        for entry in availlist:
            if all([e in qubit_subset for e in entry]):
                subset_availlist.append(entry)
        
        # If there is some availability, add this to new availability
        if len(subset_availlist):
            subset_availability[gate] = subset_availlist

    subset_graph = pspec.qubitgraph.subgraph(qubit_subset)
    
    return subset_availability, subset_graph


def _get_noisy_povm(num_qubits, readout_error):
    povm_layers = {}
    Mdefault_baseNQ = _povm.ComputationalBasisPOVM(num_qubits, 'chp')
    err_gate1Q = _op.ComposedOp([
        _op.StaticStandardOp('Gi', 'chp'),
        _op.DepolarizeOp(2, evotype='chp', initial_rate=readout_error)
    ])
    #err_gates = [err_gate1Q.copy() for i in range(num_qubits)] if independent_gates else [err_gate1Q,] * num_qubits
    err_gates = [err_gate1Q,] * num_qubits
    err_gateNQ = _op.ComposedOp([
        _op.EmbeddedOp(range(num_qubits), [i], err_gates[i]) for i in range(num_qubits)])
    povm_layers['Mdefault'] = _ComposedPOVM(err_gateNQ, Mdefault_baseNQ)
    return povm_layers


# Worker for multiprocessing
def _handle_iteration(args):
    mdl, datadir, width, iteration = args

    time1 = time.time()

    # Pull circuits from disk (this is the cost savings, no resampling of layers)
    edesign = pygsti.io.load_edesign_from_dir(datadir / f'mrb_edesign_{width}_{iteration}')

    # Only take first 4 depths worth of layers
    # Gives us equal sampling data for all widths (and speed for low widths)
    circs = edesign.all_circuits_needing_data[:120]

    layer_infidelities = []
    for i, circ in enumerate(circs):
        # Strip initial/final clifford layers and initial Pauli randomize layer
        valid_layers = circ[2:-1]

        # We now have paired up Clifford and Pauli layers
        clifford_layers = valid_layers[::2] 
        pauli_layers = valid_layers[1::2]

        # Compute each layer infidelity
        layer_infidelities.extend([compute_layer_infidelity(mdl, c, p) for c,p in zip(clifford_layers, pauli_layers)])

    print(f'Completed sampling from iteration {iteration} in {time.time() - time1}')
    return layer_infidelities
