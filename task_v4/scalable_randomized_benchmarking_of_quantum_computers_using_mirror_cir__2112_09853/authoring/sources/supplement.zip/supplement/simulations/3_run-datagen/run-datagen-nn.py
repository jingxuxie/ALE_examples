"""Runs and analysis for crosstalk-free models via batch submission on Kahuna

This is designed to run in a job array over iterations using MPI.
"""

# Prevent numpy from fork-bombing with MPI
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['GOTO_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'

import pygsti
import numpy as np
import itertools 
import time
import sys
import pickle

sys.path.append('..')
import simtools

from mpi4py import MPI
comm = MPI.COMM_WORLD
#comm = None # Toggle for no MPI

def rankprint(string):
    if comm is None or comm.Get_rank() == 0:
        print(string)


if __name__ == '__main__':
    # Pull iteration number from environment
    job_array_id = int(os.environ.get('SLURM_ARRAY_TASK_ID', -1))
    assert (job_array_id >= 0), "Could not get job task id. Was this submitted as a SLURM job array?"

    # Could automate this, but it's fine to just match
    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    rankprint(widths)

    time0 = time.time()

    for w in widths: 
        mdlfile = f'../data/mrb_edesign_{w}_{job_array_id}/nn_ct_mdl_{w}_{job_array_id}.pkl'
        with open(mdlfile, 'rb') as f:
            mdl = pickle.load(f)
        rankprint(f'Loaded model {mdlfile} from pickle file')

        edesign_dir = f'../data/mrb_edesign_{w}_{job_array_id}/'
        rbdesign = pygsti.io.load_edesign_from_dir(edesign_dir)
        rankprint(f'Loaded MRB edesign from {edesign_dir}')

        time2 = time.time()

        # Do each circuit separately just for more verbose output
        ds = pygsti.objects.DataSet()
        for i, circ in enumerate(rbdesign.all_circuits_needing_data):
            time3 = time.time()
            # No sample error since we are using CHP with shots
            circ_ds = pygsti.construction.simulate_data(mdl, [circ], num_samples=1000, comm=comm, sample_error='none')
            rankprint(f'  Completed circuit {i} of {len(rbdesign.all_circuits_needing_data)} in {time.time() - time3:.2f} s')

            ds.add_count_dict(circ, circ_ds[circ].counts)
        
        ds_file = edesign_dir + 'nn_ct_dataset.txt'
        
        if comm is None or comm.Get_rank() == 0:
            pygsti.io.write_dataset(ds_file, ds, with_times=False)
        rankprint(f'Wrote generated dataset to {ds_file}')

        time4 = time.time()

        rankprint(f'Total time for width {w}: {time4 - time2}\n')
    rankprint(f'Total time for iteration {job_array_id}: {time4 - time0}')
