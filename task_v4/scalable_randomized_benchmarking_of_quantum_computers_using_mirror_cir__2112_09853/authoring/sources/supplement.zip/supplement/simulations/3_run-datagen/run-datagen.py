"""Runs and analysis for crosstalk-free models via batch submission on Kahuna
"""

# Prevent numpy from fork-bombing with MPI
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['GOTO_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'

import pygsti
import numpy as np
import itertools 
import time
import sys
import pickle

sys.path.append('..')
import simtools

from mpi4py import MPI
comm = MPI.COMM_WORLD
#comm = None # Toggle for no MPI

def rankprint(string):
    if comm is None or comm.Get_rank() == 0:
        print(string)

## PARAMETERS ##
modeldir = '../data/'                       # Directory with model pickle files
models = ['ctf', 'full_ct']#, 'nn_model']   # Prefixes for model pickle files to run


if __name__ == '__main__':
    # Could automate this, but it's fine to just match
    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    rankprint(widths)

    time0 = time.time()
    for mdl_name in models:
        time1 = time.time()    

        for w in widths: 
            mdlfile = modeldir + f'{mdl_name}_mdl_{w}.pkl'
            with open(mdlfile, 'rb') as f:
                mdl = pickle.load(f)
            rankprint(f'Loaded model {mdlfile} from pickle file')

            edesign_dir = f'../data/mrb_edesign_{w}_0/'
            rbdesign = pygsti.io.load_edesign_from_dir(edesign_dir)
            rankprint(f'Loaded MRB edesign from {edesign_dir}')

            time2 = time.time()

            # Do each circuit separately just for more verbose output
            ds = pygsti.objects.DataSet()
            for i, circ in enumerate(rbdesign.all_circuits_needing_data):
                time3 = time.time()
                # No sample error since we are using CHP with shots
                circ_ds = pygsti.construction.simulate_data(mdl, [circ], num_samples=1000, comm=comm, sample_error='none')
                rankprint(f'  Completed circuit {i} of {len(rbdesign.all_circuits_needing_data)} in {time.time() - time3:.2f} s')

                ds.add_count_dict(circ, circ_ds[circ].counts)
            
            ds_file = edesign_dir + f'{mdl_name}_dataset.txt'
            
            if comm is None or comm.Get_rank() == 0:
                pygsti.io.write_dataset(ds_file, ds, with_times=False)
            rankprint(f'Wrote generated dataset to {ds_file}')

            time4 = time.time()

            rankprint(f'Total time for width {w}: {time4 - time2}\n')
        rankprint(f'Total time for model {mdl_name}: {time4 - time1}')
    rankprint(f'Total time for iteration 0: {time4 - time0}')
