"""Computes the model infidelities across MRB designs
"""

import json
import numpy as np
import time
import sys 
from pathlib import Path
import pickle

sys.path.append('..')
import simtools


## PARAMETERS
datadir = Path('../data')    # Location of edesigns/models

iterations = range(50)      # Iterations to consider for RB layer samples

models = ['ctf', 'full_ct'] # Prefix of model pickle files to run

num_procs = 28              # 28 cores with Kahuna compute partition

if __name__ == '__main__':
    # Could automate this, but it's fine to just match
    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    time0 = time.time()
    for mdl_name in models:
        time1 = time.time()    

        infidelities = {w: simtools.compute_model_infidelity(datadir / f'{mdl_name}_mdl_{w}.pkl',
            datadir, iterations, 0, num_procs) for w in widths}

        with open(f'avg_{mdl_name}_infid.json', 'w') as f:
            json.dump(infidelities, f)

        print(f'Total time for model {mdl_name}: {time.time() - time1}')
    print(f'Total time for all models: {time.time() - time0}')
