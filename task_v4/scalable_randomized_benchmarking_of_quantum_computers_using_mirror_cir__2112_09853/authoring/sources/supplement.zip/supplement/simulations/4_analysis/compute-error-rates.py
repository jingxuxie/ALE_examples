"""Computes the observed MRB error rates for each dataset run
"""

import json
import numpy as np
import multiprocessing as mp
import time
import sys 
from pathlib import Path
import pickle

import pygsti

sys.path.append('..')
import simtools


## PARAMETERS
datadir = Path('../data')    # Location of edesigns/models/datasets

iterations = range(50)      # Iterations to consider for RB layer samples

num_procs = 28              # 28 cores with Kahuna compute partition


def generate_error_rate_per_width(jsonfile, dsname, widths, iteration):
    start = time.time()
    results_per_width = {}
    for w in widths:
        edesign = pygsti.io.load_edesign_from_dir(datadir / f'mrb_edesign_{w}_{iteration}')
        dataset = pygsti.io.load_dataset(datadir / f'mrb_edesign_{w}_{iteration}' / dsname)

        protocol = pygsti.protocols.RB(datatype = 'adjusted_success_probabilities', defaultfit='A-fixed')

        try:
            results = protocol.run(pygsti.protocols.ProtocolData(edesign, dataset))
        except Exception as err:
            print(f'WARNING: Failed for width {w}')
            continue

        fit = results.fits['A-fixed']
        results_per_width[w] = {'r': fit.estimates['r'], 'r_std': fit.stds['r']}
        
    print(f'Generated results in {time.time() - start:.2f} s')

    # Dump to JSON for next time
    with open(jsonfile, 'w') as f:
        json.dump(results_per_width, f)

def _handle_nn_iter(args):
    jsonfile, dsfile, widths, iteration = args

    time1 = time.time()

    generate_error_rate_per_width(jsonfile, dsfile, widths, iteration)

    print(f'Finished nearest-neighbor fits for iteration {iteration} in {time.time() - time1:.2f} s')

if __name__ == '__main__':
    # Could automate this, but it's fine to just match
    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    # Iteration 0 has CTF and full CT fits (for Figure 2b)
    time0 = time.time()
    generate_error_rate_per_width('ctf_rates.json', 'ctf_dataset.txt', widths, 0)
    print(f'Finished CTF fits in {time.time() - time0:.2f} s')

    time0 = time.time()
    generate_error_rate_per_width('full_ct_rates.json', 'full_ct_dataset.txt', widths, 0)
    print(f'Finished full CT fits in {time.time() - time0:.2f} s')

    # Should also do all nearest neighbor (for Figure 2a)
    time0 = time.time()
    with mp.Pool(num_procs) as pool:
        args = [(f'nn_ct_rates_{i}.json', 'nn_ct_dataset.txt', widths, i) for i in iterations]
        pool.map(_handle_nn_iter, args)
    print(f'Finished all nearest-neighbor fits in {time.time() - time0:.2f} s')
