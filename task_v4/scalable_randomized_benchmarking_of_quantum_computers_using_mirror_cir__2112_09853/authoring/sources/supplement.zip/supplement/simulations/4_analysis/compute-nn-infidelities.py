"""Computes the model infidelities across MRB designs
"""

import json
import numpy as np
import time
import sys 
from pathlib import Path
import pickle
import os

sys.path.append('..')
import simtools


## PARAMETERS
datadir = Path('../data')    # Location of edesigns/models

iterations = range(50)      # Iterations to consider for RB layer samples

num_procs = 28              # 28 cores with Kahuna compute partition

if __name__ == '__main__':
    # Pull iteration number from environment
    job_array_id = int(os.environ.get('SLURM_ARRAY_TASK_ID', -1))
    assert (job_array_id >= 0), "Could not get job task id. Was this submitted as a SLURM job array?"
    
    # Could automate this, but it's fine to just match
    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    time0 = time.time()
    
    modelnames = [datadir / f'mrb_edesign_{w}_{job_array_id}' / f'nn_ct_mdl_{w}_{job_array_id}.pkl' for w in widths]
    infidelities = {w: simtools.compute_model_infidelity(mdl, datadir, iterations, job_array_id, num_procs)
        for w, mdl in zip(widths, modelnames)}

    with open(f'avg_nn_ct_{job_array_id}_infid.json', 'w') as f:
        json.dump(infidelities, f)

    print(f'Total time for nearest-neighbor model on iteration {job_array_id}: {time.time() - time1}')
