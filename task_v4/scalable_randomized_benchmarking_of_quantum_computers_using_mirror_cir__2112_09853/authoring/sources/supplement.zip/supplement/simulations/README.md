# Clifford Mirror RB Simulations

This folder contains all the data and simulation code needed to generate Figure 2 of the paper.

## Table of Contents

This directory contains four main folders, each with one step of the full workflow
described in Section A of the Supplemental Material.

- `1_construct-edesigns`: Construct the PyGSTi experiment designs. This includes sampling the mirror RB circuits.
- `2_construct-models`: Construct/sample the 3 PyGSTi parameterized models that are simulated in the paper:
    crosstalk-free (`ctf`), full CNOT crosstalk (`full_ct`), and nearest-neighbor crosstalk (`nn_ct`).
- `3_run-datagen`: Use CHP (via PyGSTi) to simulate the RB experiment designs.
- `4_analysis`: Calculate RB error rates from simulated data, and calculate the model infidelities.

All four workflows load/store to a folder called `data`, which is not included due to its size. Instead,
summary data from the simulations that are sufficient to regenerate figure 2 are included.

In addition to these folders, there are additional files used throughout the workflow:

- `simtools.py`: Utility functions for creating PyGSTi models and calculating infidelities
- `composedcrosstalkmodel.py`: A Python class similar to PyGSTi's `LocalNoiseModel` but with extensions for crosstalk noise and padding idles.
    All 3 models described above use this class (even crosstalk-free, for the padded idle capability).
- `requirements.txt`: A pip requirements file
- `plotting.ipynb`: Jupyter notebook that generates the plots presented in Figure 2 of the paper.

## Software

This data was generated and analyzed using the PyGSTi package on commit `ff8047a`.

A Python virtual environment can be generated using the following set of commands:

```
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Additionally, Scott Aaronson's CHP code needs to be compiled. This can be done as follows:

```
wget https://www.scottaaronson.com/chp/chp.c
gcc chp.c -o chp
```

The `venv` Python virtual environment and `chp` executable are needed by the job submission scripts.

## Data Generation

The following set of instructions should regenerate all the data needed for Figure 2.
This assumes the user is running in an HPC setting with SLURM and MPI.

Various stages use different parallelization mechanisms, including SLURM job arrays,
MPI, and Python multiprocessing; these will be mentioned as they come up.

### Edesign Generation

```
cd 1_construct-edesigns/
sbatch construct-edesigns.sbatch         # SLURM job array over MRB samples
```

### Model Construction

```
cd 2_construct-models/
sbatch construct-models.sbatch
sbatch construct-nn-models.sbatch        # SLURM job array over MRB samples
```

### Dataset Simulation

```
cd 3_run-datagen/
sbatch run-datagen.sbatch                # MPI over CHP shots
sbatch run-datagen-nn.sbatch             # MPI over CHP shots & SLURM job array over MRB samples
```

### Error Rate/Infidelity Extraction

```
cd 4_analysis/
sbatch compute-error-rates.sbatch        # Python multiprocessing over MRB samples
sbatch compute-infidelities.sbatch       # Python multiprocessing over MRB samples
sbatch compute-nn-infidelities.sbatch    # Python multiprocessing & SLURM job array over MRB samples (i.e. double for loop)
```

The double loop over MRB samples in the final step is because for each nearest neighbor model (first MRB sample loop),
all MRB samples (second MRB sample loop) are used to get dressed-Pauli layer samples.
The SLURM job array is used for the first loop, and Python multiprocessing for the second loop
(as this parallelization is also helpful for the crosstalk-free and full CNOT crosstalk models as well).

At this point, `4_analysis` should be populated with the JSON files required by `plotting.ipynb`.