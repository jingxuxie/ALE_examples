"""Runs and analysis for crosstalk-free models via batch submission on Kahuna

This is designed to run in a job array over iterations.
"""

import pygsti
import numpy as np
import os
import itertools 
import time
import sys
import pickle
import multiprocessing as mp
from pathlib import Path

sys.path.append('..')
import simtools

## PARAMETERS ##
sidelength = 15         # Number of qubits per side of square lattice

# Order of magnitude error rates for choosing the maximum depth of the circuits.
oneQgate_error = 0.001      # One-qubit gate error
spam_error = 0.005          # SPAM error
twoQgate_error = 0.01       # Two-qubit gate error

chpexe = Path('../chp')     # CHP executable

savedir = Path('../data/')  # Save directory for model pickle files


def model_func_kwargs(task):
    func, args, name = task

    start = time.time()
    model = func(*args)
    print(f'Time for {name} model generation: {time.time() - start}')

    with open(savedir / name, 'wb') as f:
        pickle.dump(model, f)


if __name__ == '__main__':
    pspec = simtools.create_processor_spec(sidelength)

    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    qsubsets = simtools.select_qubit_subsets(widths, sidelength)

    sim = pygsti.objects.CHPForwardSimulator(chpexe.resolve(), shots=100)

    start = time.time() 
    with mp.Pool(len(qsubsets)) as pool:
        fns = [simtools.create_crosstalk_free_model,] * len(widths)
        fn_args = [(pspec, sim, qsubsets[w], oneQgate_error, twoQgate_error, spam_error) for w in widths]
        names = [f'ctf_mdl_{w}.pkl' for w in widths]

        tasks = zip(fns, fn_args, names)

        pool.map(model_func_kwargs, tasks)

    print(f'Time for all CTF model generations: {time.time() - start}') 
    

    start = time.time() 
    with mp.Pool(len(qsubsets)) as pool:
        fns = [simtools.create_full_crosstalk_model,] * len(widths)
        fn_args = [(pspec, sim, qsubsets[w], oneQgate_error, twoQgate_error, spam_error) for w in widths]
        names = [f'full_ct_mdl_{w}.pkl' for w in widths]

        tasks = zip(fns, fn_args, names)

        pool.map(model_func_kwargs, tasks)

    print(f'Time for all full crosstalk model generations: {time.time() - start}') 

