"""Runs and analysis for crosstalk-free models via batch submission on Kahuna

This is designed to run in a job array over iterations.
"""

import pygsti
import numpy as np
import os
import itertools 
import time
import sys
import pickle
import multiprocessing as mp
from pathlib import Path

sys.path.append('..')
import simtools

## PARAMETERS ##
sidelength = 15         # Number of qubits per side of square lattice

# Order of magnitude error rates for choosing the maximum depth of the circuits.
oneQ_total_strength = 0.002     # Maximum total strength of errors on one-qubit gates
twoQ_total_strength = 0.02      # Maximum total strength of errors on two-qubit gates
oneQ_local_interval = [0.5, 1]  # Interval for choosing the fraction of error to be local
                                # (i.e. on targets) for one-qubit gates
twoQ_local_interval = [0.5, 1]  # Interval for choosing the fraction of error to be local
                                # (i.e. on targets) for two-qubit gates
spam_total_strength = 0.01      # Maximum total strength of errors on SPAM

random_rates = True             # Whether to use RNG when sampling nearest-neighbor models

base_seed = 20210621            # Base seed for RNG usage in model sampling

chpexe = Path('../chp')         # CHP executable

savedir = Path('../data/')      # Save directory for model pickle files


def model_func_kwargs(task):
    func, args, name = task

    start = time.time()
    model = func(*args)
    print(f'Time for {name} model generation: {time.time() - start}')

    with open(savedir / name, 'wb') as f:
        pickle.dump(model, f)


if __name__ == '__main__':
    # Pull iteration number from environment
    job_array_id = int(os.environ.get('SLURM_ARRAY_TASK_ID', -1))
    assert (job_array_id >= 0), "Could not get job task id. Was this submitted as a SLURM job array?"

    pspec = simtools.create_processor_spec(sidelength)

    widths = list(set([int(np.floor(1.33**i)) for i in range(20)])) 
    widths.sort()
    print(widths)

    qsubsets = simtools.select_qubit_subsets(widths, sidelength)

    sim = pygsti.objects.CHPForwardSimulator(chpexe.resolve(), shots=100)

    start = time.time() 
    with mp.Pool(len(qsubsets)) as pool:
        fns = [simtools.create_uncorrelated_nearest_neighbor_crosstalk_model,] * len(widths)
        
        # Select a unique seed for every iteration and width
        seeds = [base_seed + job_array_id*len(widths) + i for i in range(len(widths))]
        print(f'Using seeds: {seeds}')
        rand_states = [np.random.RandomState(s) for s in seeds]

        fn_args = [(pspec, sim, qsubsets[w], rand_states[i], random_rates,
                    oneQ_total_strength, twoQ_total_strength,
                    oneQ_local_interval, twoQ_local_interval,
                    spam_total_strength) for i,w in enumerate(widths)]
        names = [f'mrb_edesign_{w}_{job_array_id}/nn_ct_mdl_{w}_{job_array_id}.pkl' for w in widths]

        tasks = zip(fns, fn_args, names)

        pool.map(model_func_kwargs, tasks)

    print(f'Time for all nearest-neighbor model generations: {time.time() - start}') 

